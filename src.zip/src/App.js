import React, { useState } from 'react';
import { CssBaseline, Box } from '@mui/material';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Employee from './components/Employee';
import User from './components/User';
import Product from './components/Product';

const App = () => {
  const [activeComponent, setActiveComponent] = useState('Employee');

  const renderComponent = () => {
    switch (activeComponent) {
      case 'Employee':
        return <Employee />;
      case 'User':
        return <User />;
      case 'Product':
        return <Product />;
      default:
        return <Employee />;
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <CssBaseline />
      <Navbar />
      <Box sx={{ display: 'flex', flexGrow: 1 }}>
        <Sidebar activeComponent={activeComponent} setActiveComponent={setActiveComponent} />
        <Box sx={{ flexGrow: 1, p: 3 }}>{renderComponent()}</Box>
      </Box>
      <Footer />
    </Box>
  );
};

export default App;
