import React, { useEffect, useState } from 'react';
import { fetchProducts, addProduct, deleteProduct } from '../api/productApi';
import { Card, CardContent, Typography, Button, Grid } from '@mui/material';
import Swal from 'sweetalert2';

const Product = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetchProducts().then((data) => setProducts(data));
  }, []);

  const handleDeleteProduct = (id) => {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this product!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
      if (result.isConfirmed) {
        deleteProduct(id).then(() => {
          setProducts(products.filter((product) => product.id !== id));
          Swal.fire('Deleted!', 'Product has been deleted.', 'success');
        });
      }
    });
  };

  return (
    <Grid container spacing={2}>
      {products.map((product) => (
        <Grid item xs={12} sm={6} md={4} key={product.id}>
          <Card sx={{ backgroundColor: '#f5f5f5', mb: 2 }}>
            <CardContent>
              <Typography variant="h6">{product.name}</Typography>
              <Typography variant="body2" color="textSecondary">
                {product.description}
              </Typography>
              <Button
                variant="contained"
                color="error"
                sx={{ mt: 2 }}
                onClick={() => handleDeleteProduct(product.id)}
              >
                Delete
              </Button>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default Product;
