export const fetchProducts = () => {
    return new Promise((resolve) => {
      const dummyProducts = [
        { id: 1, name: 'Product 1', description: 'This is product 1' },
        { id: 2, name: 'Product 2', description: 'This is product 2' },
      ];
      setTimeout(() => resolve(dummyProducts), 1000);
    });
  };
  
  export const deleteProduct = (id) => {
    return new Promise((resolve) => {
      setTimeout(() => resolve(`Product with ID ${id} deleted`), 1000);
    });
  };
  